package com.example.kaktuns_project_media;

import javafx.application.Application;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.MenuItem;
import javafx.scene.image.Image;
import javafx.scene.layout.TilePane;
import javafx.scene.media.MediaPlayer;
import javafx.stage.Popup;
import javafx.stage.Stage;

import java.util.Objects;

public class Main extends Application {
    Scene scene,scene2;
    //@FXML
    //MenuItem deleteMedia;

    @Override
    public void start(Stage stage)  {
        try{
            Parent root=FXMLLoader.load(Objects.requireNonNull(getClass().getResource("v6.fxml")));
            scene = new Scene(root);
            Parent root2=FXMLLoader.load(Objects.requireNonNull(getClass().getResource("testv2.fxml")));
            scene2 = new Scene(root2);
            stage.setScene(scene);

            Button deleteMedia=new Button();
            deleteMedia.setLayoutX(100);
            deleteMedia.setLayoutX(100);

            deleteMedia.setOnAction(e->stage.setScene(scene2));

            stage.setTitle("Kaktuns");
            Image image=new Image("C:\\Users\\ulwar\\IdeaProjects\\kaktuns\\src\\main\\java\\com\\example\\kaktuns_project_media\\logo.png");
            stage.getIcons().add(image);

            stage.show();


        }catch (Exception e){
            e.printStackTrace();
        }
    }

    public static void main(String[] args) {
        launch(args);
    }
}
